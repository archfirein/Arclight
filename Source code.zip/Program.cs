using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;

namespace ArcLight
{
    // ==========================================
    // WIN32 DONANIMSAL GAMMA KONTROLCÜSÜ
    // ==========================================
    public static class GammaController
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct RAMP
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
            public ushort[] Red;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
            public ushort[] Green;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
            public ushort[] Blue;
        }

        [DllImport("gdi32.dll")]
        public static extern bool SetDeviceGammaRamp(IntPtr hdc, ref RAMP lpRamp);

        [DllImport("gdi32.dll")]
        public static extern bool GetDeviceGammaRamp(IntPtr hdc, ref RAMP lpRamp);

        [DllImport("user32.dll")]
        public static extern IntPtr GetDC(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);

        private static RAMP? _originalRamp = null;

        public static void SaveOriginal()
        {
            try
            {
                IntPtr hdc = GetDC(IntPtr.Zero);
                if (hdc != IntPtr.Zero)
                {
                    RAMP current = new RAMP();
                    if (GetDeviceGammaRamp(hdc, ref current))
                    {
                        _originalRamp = current;
                    }
                    ReleaseDC(IntPtr.Zero, hdc);
                }
            }
            catch { }
        }

        public static void SetColorTemperatureAndBrightness(int kelvin, int brightnessPercent)
        {
            try
            {
                double rFactor, gFactor, bFactor;
                KelvinToRgb(kelvin, out rFactor, out gFactor, out bFactor);

                double bRatio = (double)brightnessPercent / 100.0;
                rFactor *= bRatio;
                gFactor *= bRatio;
                bFactor *= bRatio;

                RAMP ramp = new RAMP
                {
                    Red = new ushort[256],
                    Green = new ushort[256],
                    Blue = new ushort[256]
                };

                for (int i = 0; i < 256; i++)
                {
                    double baseVal = i * 256.0;
                    ramp.Red[i] = (ushort)Math.Max(0, Math.Min(65535, (int)(baseVal * rFactor)));
                    ramp.Green[i] = (ushort)Math.Max(0, Math.Min(65535, (int)(baseVal * gFactor)));
                    ramp.Blue[i] = (ushort)Math.Max(0, Math.Min(65535, (int)(baseVal * bFactor)));
                }

                IntPtr hdc = GetDC(IntPtr.Zero);
                if (hdc != IntPtr.Zero)
                {
                    SetDeviceGammaRamp(hdc, ref ramp);
                    ReleaseDC(IntPtr.Zero, hdc);
                }
            }
            catch { }
        }

        public static void RestoreDefault()
        {
            try
            {
                IntPtr hdc = GetDC(IntPtr.Zero);
                if (hdc != IntPtr.Zero)
                {
                    if (_originalRamp.HasValue)
                    {
                        RAMP orig = _originalRamp.Value;
                        SetDeviceGammaRamp(hdc, ref orig);
                    }
                    else
                    {
                        RAMP linear = new RAMP
                        {
                            Red = new ushort[256],
                            Green = new ushort[256],
                            Blue = new ushort[256]
                        };
                        for (int i = 0; i < 256; i++)
                        {
                            ushort val = (ushort)(i * 256);
                            linear.Red[i] = val;
                            linear.Green[i] = val;
                            linear.Blue[i] = val;
                        }
                        SetDeviceGammaRamp(hdc, ref linear);
                    }
                    ReleaseDC(IntPtr.Zero, hdc);
                }
            }
            catch { }
        }

        private static void KelvinToRgb(int kelvin, out double r, out double g, out double b)
        {
            double temp = kelvin / 100.0;
            double red, green, blue;

            if (temp <= 66.0)
            {
                red = 255.0;
                green = 99.4708025861 * Math.Log(temp) - 161.1195681661;
                if (temp <= 19.0)
                    blue = 0.0;
                else
                    blue = 138.5177312231 * Math.Log(temp - 10.0) - 305.0447927307;
            }
            else
            {
                red = 329.698727446 * Math.Pow(temp - 60.0, -0.1332047592);
                green = 288.1221695283 * Math.Pow(temp - 60.0, -0.0755148492);
                blue = 255.0;
            }

            r = Math.Max(0.0, Math.Min(255.0, red)) / 255.0;
            g = Math.Max(0.0, Math.Min(255.0, green)) / 255.0;
            b = Math.Max(0.0, Math.Min(255.0, blue)) / 255.0;
        }
    }

    // ==========================================
    // ÇOKLU DİL DESTEĞİ (LOCALIZATION)
    // ==========================================
    public static class Loc
    {
        public static string CurrentLang = "tr"; // tr, en, es, fr, zh, ja, ko

        private static Dictionary<string, Dictionary<string, string>> _dict = new Dictionary<string, Dictionary<string, string>>
        {
            // TÜRKÇE
            { "tr", new Dictionary<string, string> {
                { "TabLight", "💡 Işık & Parlaklık" },
                { "TabLocation", "📍 Lokasyon & Saat" },
                { "TabSettings", "⚙️ Ayarlar & Dil" },
                { "NightModeOn", "🌙 GECE MODU: AÇIK" },
                { "NightModeOff", "☀️ GÜNDÜZ MODU: KAPALI" },
                { "ClickToToggle", "(Tek tıkla açın veya kapatın)" },
                { "StatusNight", "Gece Modu devrede. Mavi ışık filtreleniyor." },
                { "StatusDay", "Ekran standart gün ışığı modunda." },
                { "ColorTemp", "🔥 Renk Sıcaklığı (Mavi Işık Filtresi)" },
                { "Brightness", "☀️ Ekran Parlaklığı" },
                { "PresetCandle", "Mum (2200K)" },
                { "PresetNight", "Gece (3400K)" },
                { "PresetSunset", "Akşam (4500K)" },
                { "PresetNormal", "Normal (6500K)" },
                { "DescCandle", "Mum Işığı / Çok Sıcak" },
                { "DescNight", "Rahat Gece Modu" },
                { "DescSunset", "Akşam Işığı" },
                { "DescNormal", "Normal Gün Işığı" },
                { "SchedTitle", "📍 Lokasyon ve Akıllı Zamanlama" },
                { "ModeSun", "Güneş Takibi (Konuma Göre)" },
                { "ModeCustom", "Özel Saat Aralığı" },
                { "ModeManual", "Manuel (Zamanlayıcı Yok)" },
                { "CitySelect", "Şehir Seçin:" },
                { "SunriseSunset", "🌅 Gün Doğumu: {0}   |   🌇 Gün Batımı: {1}\n(Güneş saatlerine göre otomatik geçiş yapar)" },
                { "StartTime", "🌙 Başlama Saati (Gece):" },
                { "EndTime", "☀️ Bitiş Saati (Gündüz):" },
                { "LangTitle", "🌐 Uygulama Dili / Language" },
                { "AutoStart", "Windows açıldığında otomatik başlasın" },
                { "MinimizeTray", "Çarpı (X) ile kapatınca saatin yanına küçülsün" },
                { "ExitApp", "🛑 ArcLight'ı Kapat ve Ekranı Sıfırla" },
                { "TrayToggle", "Gece Modunu Aç / Kapat" },
                { "TrayOpen", "ArcLight Ayarlarını Aç" },
                { "TrayExit", "ArcLight'tan Çıkış" }
            }},
            // ENGLISH
            { "en", new Dictionary<string, string> {
                { "TabLight", "💡 Light & Brightness" },
                { "TabLocation", "📍 Location & Schedule" },
                { "TabSettings", "⚙️ Settings & Language" },
                { "NightModeOn", "🌙 NIGHT MODE: ON" },
                { "NightModeOff", "☀️ DAY MODE: OFF" },
                { "ClickToToggle", "(Click to toggle on / off)" },
                { "StatusNight", "Night Mode is active. Blue light filtered." },
                { "StatusDay", "Standard daylight mode is active." },
                { "ColorTemp", "🔥 Color Temperature (Blue Light Filter)" },
                { "Brightness", "☀️ Screen Brightness" },
                { "PresetCandle", "Candle (2200K)" },
                { "PresetNight", "Night (3400K)" },
                { "PresetSunset", "Sunset (4500K)" },
                { "PresetNormal", "Normal (6500K)" },
                { "DescCandle", "Candlelight / Very Warm" },
                { "DescNight", "Cozy Night Mode" },
                { "DescSunset", "Sunset / Evening Light" },
                { "DescNormal", "Natural Daylight" },
                { "SchedTitle", "📍 Location & Smart Schedule" },
                { "ModeSun", "Sun Tracking (By Location)" },
                { "ModeCustom", "Custom Time Range" },
                { "ModeManual", "Manual (No Timer)" },
                { "CitySelect", "Select City:" },
                { "SunriseSunset", "🌅 Sunrise: {0}   |   🌇 Sunset: {1}\n(Automatically switches based on solar movement)" },
                { "StartTime", "🌙 Start Time (Night):" },
                { "EndTime", "☀️ End Time (Day):" },
                { "LangTitle", "🌐 Application Language" },
                { "AutoStart", "Start automatically with Windows" },
                { "MinimizeTray", "Minimize to system tray on close (X)" },
                { "ExitApp", "🛑 Exit ArcLight & Reset Screen" },
                { "TrayToggle", "Toggle Night Mode" },
                { "TrayOpen", "Open ArcLight Settings" },
                { "TrayExit", "Exit ArcLight" }
            }},
            // ESPAÑOL
            { "es", new Dictionary<string, string> {
                { "TabLight", "💡 Luz y Brillo" },
                { "TabLocation", "📍 Ubicación y Horario" },
                { "TabSettings", "⚙️ Ajustes e Idioma" },
                { "NightModeOn", "🌙 MODO NOCHE: ACTIVADO" },
                { "NightModeOff", "☀️ MODO DÍA: DESACTIVADO" },
                { "ClickToToggle", "(Clic para activar o desactivar)" },
                { "StatusNight", "Modo noche activo. Luz azul filtrada." },
                { "StatusDay", "Modo de luz diurna estándar activo." },
                { "ColorTemp", "🔥 Temperatura de Color" },
                { "Brightness", "☀️ Brillo de Pantalla" },
                { "PresetCandle", "Vela (2200K)" },
                { "PresetNight", "Noche (3400K)" },
                { "PresetSunset", "Tarde (4500K)" },
                { "PresetNormal", "Normal (6500K)" },
                { "DescCandle", "Luz de Vela / Muy Cálido" },
                { "DescNight", "Modo Noche Cómodo" },
                { "DescSunset", "Luz de Atardecer" },
                { "DescNormal", "Luz Diurna Natural" },
                { "SchedTitle", "📍 Ubicación y Horario Inteligente" },
                { "ModeSun", "Seguimiento Solar (Ubicación)" },
                { "ModeCustom", "Horas Personalizadas" },
                { "ModeManual", "Manual (Sin Temporizador)" },
                { "CitySelect", "Seleccionar Ciudad:" },
                { "SunriseSunset", "🌅 Amanecer: {0}   |   🌇 Atardecer: {1}\n(Cambia automáticamente con la posición del sol)" },
                { "StartTime", "🌙 Hora de Inicio (Noche):" },
                { "EndTime", "☀️ Hora de Fin (Día):" },
                { "LangTitle", "🌐 Idioma de la Aplicación" },
                { "AutoStart", "Iniciar automáticamente con Windows" },
                { "MinimizeTray", "Minimizar a la bandeja al cerrar (X)" },
                { "ExitApp", "🛑 Cerrar ArcLight y Restablecer Pantalla" },
                { "TrayToggle", "Alternar Modo Noche" },
                { "TrayOpen", "Abrir Ajustes de ArcLight" },
                { "TrayExit", "Salir de ArcLight" }
            }},
            // FRANÇAIS
            { "fr", new Dictionary<string, string> {
                { "TabLight", "💡 Lumière et Luminosité" },
                { "TabLocation", "📍 Emplacement et Heures" },
                { "TabSettings", "⚙️ Paramètres et Langue" },
                { "NightModeOn", "🌙 MODE NUIT : ACTIVÉ" },
                { "NightModeOff", "☀️ MODE JOUR : DÉSACTIVÉ" },
                { "ClickToToggle", "(Cliquez pour activer ou désactiver)" },
                { "StatusNight", "Mode nuit actif. Lumière bleue filtrée." },
                { "StatusDay", "Mode lumière du jour standard actif." },
                { "ColorTemp", "🔥 Température de Couleur" },
                { "Brightness", "☀️ Luminosité de l'écran" },
                { "PresetCandle", "Bougie (2200K)" },
                { "PresetNight", "Nuit (3400K)" },
                { "PresetSunset", "Soir (4500K)" },
                { "PresetNormal", "Normal (6500K)" },
                { "DescCandle", "Lueur de Bougie / Très Chaud" },
                { "DescNight", "Mode Nuit Confortable" },
                { "DescSunset", "Lumière du Crépuscule" },
                { "DescNormal", "Lumière du Jour Naturelle" },
                { "SchedTitle", "📍 Emplacement et Planification" },
                { "ModeSun", "Suivi Solaire (Par Emplacement)" },
                { "ModeCustom", "Plage Horaire Personnalisée" },
                { "ModeManual", "Manuel (Sans Minuteur)" },
                { "CitySelect", "Choisir une Ville :" },
                { "SunriseSunset", "🌅 Lever du Soleil : {0}   |   🌇 Coucher : {1}\n(Bascule automatiquement selon le soleil)" },
                { "StartTime", "🌙 Début (Nuit) :" },
                { "EndTime", "☀️ Fin (Jour) :" },
                { "LangTitle", "🌐 Langue de l'Application" },
                { "AutoStart", "Lancer automatiquement avec Windows" },
                { "MinimizeTray", "Réduire dans la zone de notification à la fermeture (X)" },
                { "ExitApp", "🛑 Quitter ArcLight et Réinitialiser" },
                { "TrayToggle", "Basculer le Mode Nuit" },
                { "TrayOpen", "Ouvrir ArcLight" },
                { "TrayExit", "Quitter ArcLight" }
            }},
            // 简体中文 (CHINESE)
            { "zh", new Dictionary<string, string> {
                { "TabLight", "💡 光线与亮度" },
                { "TabLocation", "📍 位置与计划" },
                { "TabSettings", "⚙️ 设置与语言" },
                { "NightModeOn", "🌙 夜间模式：已开启" },
                { "NightModeOff", "☀️ 日间模式：已关闭" },
                { "ClickToToggle", "(单击即可开启或关闭)" },
                { "StatusNight", "夜间护眼模式运行中，过滤蓝光。" },
                { "StatusDay", "标准日光模式运行中。" },
                { "ColorTemp", "🔥 色温调节 (防蓝光)" },
                { "Brightness", "☀️ 屏幕亮度" },
                { "PresetCandle", "烛光 (2200K)" },
                { "PresetNight", "夜间 (3400K)" },
                { "PresetSunset", "傍晚 (4500K)" },
                { "PresetNormal", "正常 (6500K)" },
                { "DescCandle", "温馨烛光 / 超暖色" },
                { "DescNight", "舒适夜间模式" },
                { "DescSunset", "傍晚柔和光" },
                { "DescNormal", "自然日光" },
                { "SchedTitle", "📍 位置与智能计划" },
                { "ModeSun", "太阳跟随 (基于地理位置)" },
                { "ModeCustom", "自定义时间段" },
                { "ModeManual", "手动模式 (无计划)" },
                { "CitySelect", "选择城市：" },
                { "SunriseSunset", "🌅 日出：{0}   |   🌇 日落：{1}\n(根据太阳升落自动切换护眼模式)" },
                { "StartTime", "🌙 开启时间 (夜间)：" },
                { "EndTime", "☀️ 关闭时间 (日间)：" },
                { "LangTitle", "🌐 界面语言 / Language" },
                { "AutoStart", "开机自动随 Windows 启动" },
                { "MinimizeTray", "点击关闭 (X) 时最小化到托盘" },
                { "ExitApp", "🛑 退出 ArcLight 并恢复屏幕" },
                { "TrayToggle", "开启/关闭夜间模式" },
                { "TrayOpen", "打开 ArcLight 设置" },
                { "TrayExit", "退出 ArcLight" }
            }},
            // 日本語 (JAPANESE)
            { "ja", new Dictionary<string, string> {
                { "TabLight", "💡 明るさと光" },
                { "TabLocation", "📍 位置とスケジュール" },
                { "TabSettings", "⚙️ 設定と言語" },
                { "NightModeOn", "🌙 夜間モード：オン" },
                { "NightModeOff", "☀️ 昼間モード：オフ" },
                { "ClickToToggle", "(クリックでオン/オフ切り替え)" },
                { "StatusNight", "夜間モード稼働中。ブルーライトをカット。" },
                { "StatusDay", "標準の昼光モードです。" },
                { "ColorTemp", "🔥 色温度 (ブルーライトカット)" },
                { "Brightness", "☀️ 画面の明るさ" },
                { "PresetCandle", "ろうそく (2200K)" },
                { "PresetNight", "夜間 (3400K)" },
                { "PresetSunset", "夕方 (4500K)" },
                { "PresetNormal", "標準 (6500K)" },
                { "DescCandle", "キャンドル / 超暖色" },
                { "DescNight", "快適な夜間モード" },
                { "DescSunset", "夕暮れの光" },
                { "DescNormal", "自然な昼光" },
                { "SchedTitle", "📍 位置とスマートスケジュール" },
                { "ModeSun", "太陽追跡 (位置ベース)" },
                { "ModeCustom", "カスタム時間範囲" },
                { "ModeManual", "手動 (タイマーなし)" },
                { "CitySelect", "都市を選択：" },
                { "SunriseSunset", "🌅 日の出：{0}   |   🌇 日の入り：{1}\n(日の出・日の入り時刻に合わせて自動切り替え)" },
                { "StartTime", "🌙 開始時間 (夜)：" },
                { "EndTime", "☀️ 終了時間 (昼)：" },
                { "LangTitle", "🌐 言語選択 / Language" },
                { "AutoStart", "Windows起動時に自動実行" },
                { "MinimizeTray", "閉じる(X)でタスクトレイに最小化" },
                { "ExitApp", "🛑 ArcLightを終了してリセット" },
                { "TrayToggle", "夜間モードの切り替え" },
                { "TrayOpen", "ArcLight設定を開く" },
                { "TrayExit", "ArcLightの終了" }
            }},
            // 한국어 (KOREAN)
            { "ko", new Dictionary<string, string> {
                { "TabLight", "💡 조명 및 밝기" },
                { "TabLocation", "📍 위치 및 일정" },
                { "TabSettings", "⚙️ 설정 및 언어" },
                { "NightModeOn", "🌙 야간 모드: 켜짐" },
                { "NightModeOff", "☀️ 주간 모드: 꺼짐" },
                { "ClickToToggle", "(클릭하여 켜기 / 끄기)" },
                { "StatusNight", "야간 모드가 켜져 있습니다. 블루라이트 차단 중." },
                { "StatusDay", "표준 주간 모드입니다." },
                { "ColorTemp", "🔥 색온도 (블루라이트 필터)" },
                { "Brightness", "☀️ 화면 밝기" },
                { "PresetCandle", "촛불 (2200K)" },
                { "PresetNight", "야간 (3400K)" },
                { "PresetSunset", "일몰 (4500K)" },
                { "PresetNormal", "표준 (6500K)" },
                { "DescCandle", "촛불 불빛 / 따뜻한 색" },
                { "DescNight", "편안한 야간 모드" },
                { "DescSunset", "노을빛 / 저녁 조명" },
                { "DescNormal", "자연 주광" },
                { "SchedTitle", "📍 위치 및 스마트 일정" },
                { "ModeSun", "태양 추적 (위치 기반)" },
                { "ModeCustom", "사용자 지정 시간 범위" },
                { "ModeManual", "수동 (일정 없음)" },
                { "CitySelect", "도시 선택:" },
                { "SunriseSunset", "🌅 일출: {0}   |   🌇 일몰: {1}\n(태양 이동에 따라 자동으로 전환됩니다)" },
                { "StartTime", "🌙 시작 시간 (야간):" },
                { "EndTime", "☀️ 종료 시간 (주간):" },
                { "LangTitle", "🌐 인터페이스 언어 / Language" },
                { "AutoStart", "Windows 시작 시 자동 실행" },
                { "MinimizeTray", "닫기(X) 클릭 시 시스템 트레이로 최소화" },
                { "ExitApp", "🛑 ArcLight 종료 및 화면 복원" },
                { "TrayToggle", "야간 모드 켜기/끄기" },
                { "TrayOpen", "ArcLight 설정 열기" },
                { "TrayExit", "ArcLight 종료" }
            }}
        };

        public static string T(string key)
        {
            if (_dict.ContainsKey(CurrentLang) && _dict[CurrentLang].ContainsKey(key))
            {
                return _dict[CurrentLang][key];
            }
            if (_dict["en"].ContainsKey(key))
            {
                return _dict["en"][key];
            }
            return key;
        }
    }

    // ==========================================
    // DÜNYA VE TÜRKİYE ŞEHİRLERİ (GÜNEŞ HESAPLAMA)
    // ==========================================
    public static class SolarCalculator
    {
        public class CityInfo
        {
            public string Name { get; set; }
            public double Latitude { get; set; }
            public double Longitude { get; set; }

            public CityInfo(string name, double lat, double lon)
            {
                Name = name;
                Latitude = lat;
                Longitude = lon;
            }

            public override string ToString()
            {
                return Name;
            }
        }

        public static List<CityInfo> Cities = new List<CityInfo>
        {
            // Türkiye - Büyükşehirler
            new CityInfo("İstanbul (Türkiye)", 41.0082, 28.9784),
            new CityInfo("Ankara (Türkiye)", 39.9334, 32.8597),
            new CityInfo("İzmir (Türkiye)", 38.4237, 27.1428),
            new CityInfo("Bursa (Türkiye)", 40.1885, 29.0610),
            new CityInfo("Antalya (Türkiye)", 36.8969, 30.7133),
            new CityInfo("Adana (Türkiye)", 37.0000, 35.3213),
            new CityInfo("Konya (Türkiye)", 37.8746, 32.4932),
            new CityInfo("Gaziantep (Türkiye)", 37.0662, 37.3833),
            new CityInfo("Şanlıurfa (Türkiye)", 37.1674, 38.7955),
            new CityInfo("Kocaeli / İzmit (Türkiye)", 40.7654, 29.9408),
            new CityInfo("Mersin (Türkiye)", 36.8121, 34.6415),
            new CityInfo("Diyarbakır (Türkiye)", 37.9144, 40.2306),
            new CityInfo("Hatay (Türkiye)", 36.2023, 36.1606),
            new CityInfo("Manisa (Türkiye)", 38.6191, 27.4289),
            new CityInfo("Kayseri (Türkiye)", 38.7312, 35.4787),
            new CityInfo("Samsun (Türkiye)", 41.2867, 36.3300),
            new CityInfo("Balıkesir (Türkiye)", 39.6484, 27.8826),
            new CityInfo("Kahramanmaraş (Türkiye)", 37.5858, 36.9371),
            new CityInfo("Van (Türkiye)", 38.4891, 43.4089),
            new CityInfo("Aydın (Türkiye)", 37.8560, 27.8416),
            new CityInfo("Denizli (Türkiye)", 37.7765, 29.0864),
            new CityInfo("Sakarya (Türkiye)", 40.7569, 30.3783),
            new CityInfo("Eskişehir (Türkiye)", 39.7767, 30.5206),
            new CityInfo("Trabzon (Türkiye)", 41.0027, 39.7168),
            new CityInfo("Malatya (Türkiye)", 38.3552, 38.3095),
            new CityInfo("Erzurum (Türkiye)", 39.9043, 41.2679),
            new CityInfo("Sivas (Türkiye)", 39.7477, 37.0179),
            new CityInfo("Çanakkale (Türkiye)", 40.1553, 26.4142),
            new CityInfo("Muğla / Bodrum (Türkiye)", 37.2153, 28.3636),

            // Dünya Başkentleri ve Metropolleri
            new CityInfo("London (United Kingdom)", 51.5074, -0.1278),
            new CityInfo("Paris (France)", 48.8566, 2.3522),
            new CityInfo("Berlin (Germany)", 52.5200, 13.4050),
            new CityInfo("Madrid (Spain)", 40.4168, -3.7038),
            new CityInfo("Barcelona (Spain)", 41.3851, 2.1734),
            new CityInfo("Rome (Italy)", 41.9028, 12.4964),
            new CityInfo("Amsterdam (Netherlands)", 52.3676, 4.9041),
            new CityInfo("Vienna (Austria)", 48.2082, 16.3738),
            new CityInfo("New York (USA)", 40.7128, -74.0060),
            new CityInfo("Los Angeles (USA)", 34.0522, -118.2437),
            new CityInfo("Chicago (USA)", 41.8781, -87.6298),
            new CityInfo("Toronto (Canada)", 43.6532, -79.3832),
            new CityInfo("Mexico City (Mexico)", 19.4326, -99.1332),
            new CityInfo("São Paulo (Brazil)", -23.5505, -46.6333),
            new CityInfo("Buenos Aires (Argentina)", -34.6037, -58.3816),
            new CityInfo("Tokyo (Japan)", 35.6762, 139.6503),
            new CityInfo("Osaka (Japan)", 34.6937, 135.5023),
            new CityInfo("Seoul (South Korea)", 37.5665, 126.9780),
            new CityInfo("Busan (South Korea)", 35.1796, 129.0756),
            new CityInfo("Beijing (China)", 39.9042, 116.4074),
            new CityInfo("Shanghai (China)", 31.2304, 121.4737),
            new CityInfo("Hong Kong", 22.3193, 114.1694),
            new CityInfo("Taipei (Taiwan)", 25.0330, 121.5654),
            new CityInfo("Singapore", 1.3521, 103.8198),
            new CityInfo("Dubai (UAE)", 25.2048, 55.2708),
            new CityInfo("Sydney (Australia)", -33.8688, 151.2093)
        };

        public static void CalculateSunriseSunset(double lat, double lon, DateTime date, out TimeSpan sunrise, out TimeSpan sunset)
        {
            int dayOfYear = date.DayOfYear;
            double gamma = 2.0 * Math.PI / 365.0 * (dayOfYear - 1 + (date.Hour - 12) / 24.0);

            double eqtime = 229.18 * (0.000075 + 0.001868 * Math.Cos(gamma) - 0.032077 * Math.Sin(gamma)
                            - 0.014615 * Math.Cos(2 * gamma) - 0.040849 * Math.Sin(2 * gamma));

            double decl = 0.006918 - 0.399912 * Math.Cos(gamma) + 0.070257 * Math.Sin(gamma)
                          - 0.006758 * Math.Cos(2 * gamma) + 0.000907 * Math.Sin(2 * gamma);

            double latRad = lat * Math.PI / 180.0;
            double zenith = 90.833 * Math.PI / 180.0;

            double cosH = (Math.Cos(zenith) - Math.Sin(latRad) * Math.Sin(decl)) / (Math.Cos(latRad) * Math.Cos(decl));

            if (cosH > 1.0)
            {
                sunrise = TimeSpan.FromHours(6);
                sunset = TimeSpan.FromHours(18);
                return;
            }
            if (cosH < -1.0)
            {
                sunrise = TimeSpan.FromHours(0);
                sunset = TimeSpan.FromHours(24);
                return;
            }

            double H = Math.Acos(cosH) * 180.0 / Math.PI;

            double timeDiff = 4.0 * lon;
            double noonUtc = 720.0 - timeDiff - eqtime;
            double sunriseUtc = noonUtc - H * 4.0;
            double sunsetUtc = noonUtc + H * 4.0;

            double tzOffsetMinutes = TimeZoneInfo.Local.GetUtcOffset(date).TotalMinutes;
            double sunriseLocal = (sunriseUtc + tzOffsetMinutes + 1440.0) % 1440.0;
            double sunsetLocal = (sunsetUtc + tzOffsetMinutes + 1440.0) % 1440.0;

            sunrise = TimeSpan.FromMinutes(sunriseLocal);
            sunset = TimeSpan.FromMinutes(sunsetLocal);
        }
    }

    // ==========================================
    // AYARLAR
    // ==========================================
    public class Settings
    {
        public bool IsEnabled = true;
        public int Kelvin = 3400;
        public int Brightness = 90;
        public bool AutoStart = false;
        public bool MinimizeToTray = true;
        public string Language = "tr";

        // Zamanlama ve Lokasyon
        public int ScheduleMode = 0; // 0: Güneş / Lokasyon, 1: Özel Saat, 2: Manuel
        public string CityName = "İstanbul (Türkiye)";
        public TimeSpan CustomStartTime = new TimeSpan(20, 0, 0); // 20:00
        public TimeSpan CustomEndTime = new TimeSpan(7, 0, 0);    // 07:00

        private static string ConfigPath
        {
            get
            {
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                string folder = Path.Combine(appData, "ArcLight");
                if (!Directory.Exists(folder)) Directory.CreateDirectory(folder);
                return Path.Combine(folder, "ayarlar.cfg");
            }
        }

        public void Save()
        {
            try
            {
                using (var sw = new StreamWriter(ConfigPath))
                {
                    sw.WriteLine("IsEnabled=" + IsEnabled);
                    sw.WriteLine("Kelvin=" + Kelvin);
                    sw.WriteLine("Brightness=" + Brightness);
                    sw.WriteLine("AutoStart=" + AutoStart);
                    sw.WriteLine("MinimizeToTray=" + MinimizeToTray);
                    sw.WriteLine("Language=" + Language);
                    sw.WriteLine("ScheduleMode=" + ScheduleMode);
                    sw.WriteLine("CityName=" + CityName);
                    sw.WriteLine("CustomStartTime=" + CustomStartTime.ToString(@"hh\:mm"));
                    sw.WriteLine("CustomEndTime=" + CustomEndTime.ToString(@"hh\:mm"));
                }
            }
            catch { }
        }

        public static Settings Load()
        {
            var s = new Settings();
            try
            {
                if (File.Exists(ConfigPath))
                {
                    foreach (var line in File.ReadAllLines(ConfigPath))
                    {
                        var parts = line.Split('=');
                        if (parts.Length == 2)
                        {
                            string key = parts[0].Trim();
                            string val = parts[1].Trim();
                            if (key == "IsEnabled") bool.TryParse(val, out s.IsEnabled);
                            if (key == "Kelvin") int.TryParse(val, out s.Kelvin);
                            if (key == "Brightness") int.TryParse(val, out s.Brightness);
                            if (key == "AutoStart") bool.TryParse(val, out s.AutoStart);
                            if (key == "MinimizeToTray") bool.TryParse(val, out s.MinimizeToTray);
                            if (key == "Language") s.Language = val;
                            if (key == "ScheduleMode") int.TryParse(val, out s.ScheduleMode);
                            if (key == "CityName") s.CityName = val;
                            if (key == "CustomStartTime") TimeSpan.TryParse(val, out s.CustomStartTime);
                            if (key == "CustomEndTime") TimeSpan.TryParse(val, out s.CustomEndTime);
                        }
                    }
                }
            }
            catch { }
            return s;
        }
    }

    // ==========================================
    // ANA PENCERE (SEKMELİ KOYU TEMA)
    // ==========================================
    public class MainForm : Form
    {
        private Settings _settings;
        private NotifyIcon _trayIcon;
        private ContextMenuStrip _trayMenu;
        private Timer _scheduleTimer;
        private Timer _saveDebounceTimer;

        // UI Güncelleme Koruması
        private bool _isUpdatingUI = false;
        private bool? _lastScheduleNightState = null;

        // Sekme Butonları ve Panelleri
        private Button _tabBtnLight;
        private Button _tabBtnLocation;
        private Button _tabBtnSettings;
        private Panel _panelLightTab;
        private Panel _panelLocationTab;
        private Panel _panelSettingsTab;

        // Sekme 1 (Işık) Bileşenleri
        private Button _btnToggle;
        private Label _lblStatusText;
        private Label _lblKTitle;
        private Label _lblKelvinVal;
        private TrackBar _tbKelvin;
        private Label _lblBTitle;
        private Label _lblBrightnessVal;
        private TrackBar _tbBrightness;
        private Button _btnPresetCandle;
        private Button _btnPresetNight;
        private Button _btnPresetSunset;
        private Button _btnPresetNormal;

        // Sekme 2 (Lokasyon) Bileşenleri
        private Label _lblSchedTitle;
        private RadioButton _rbSunMode;
        private RadioButton _rbCustomMode;
        private RadioButton _rbManualMode;
        private Panel _panelSunSettings;
        private Label _lblCity;
        private ComboBox _cbCity;
        private Label _lblSolarInfo;
        private Panel _panelCustomSettings;
        private Label _lblStart;
        private DateTimePicker _dtpStart;
        private Label _lblEnd;
        private DateTimePicker _dtpEnd;

        // Sekme 3 (Ayarlar & Dil) Bileşenleri
        private Label _lblLangTitle;
        private ComboBox _cbLanguage;
        private CheckBox _chkAutoStart;
        private CheckBox _chkMinimizeTray;
        private Button _btnExitApp;

        private Color _bgDark = Color.FromArgb(18, 18, 22);
        private Color _cardDark = Color.FromArgb(28, 28, 34);
        private Color _accentOrange = Color.FromArgb(249, 115, 22);
        private Color _accentGold = Color.FromArgb(251, 191, 36);
        private Color _offGray = Color.FromArgb(60, 60, 70);
        private Color _tabInactive = Color.FromArgb(28, 28, 34);
        private Color _tabActive = Color.FromArgb(40, 40, 50);

        public MainForm()
        {
            _settings = Settings.Load();
            Loc.CurrentLang = _settings.Language;
            GammaController.SaveOriginal();

            this.Icon = CreateAppIcon();
            SetupDebounceTimer();
            InitializeUI();
            SetupTrayIcon();
            SetupTimer();

            CheckScheduleAndApply(true);
        }

        private void SetupDebounceTimer()
        {
            _saveDebounceTimer = new Timer();
            _saveDebounceTimer.Interval = 400; // Kaydırıcı bırakıldıktan 400ms sonra diske yazar
            _saveDebounceTimer.Tick += (s, e) =>
            {
                _saveDebounceTimer.Stop();
                _settings.Save();
            };
        }

        private void TriggerDebouncedSave()
        {
            if (_saveDebounceTimer != null)
            {
                _saveDebounceTimer.Stop();
                _saveDebounceTimer.Start();
            }
        }

        private void InitializeUI()
        {
            this.Text = "ArcLight";
            this.Size = new Size(510, 640);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.BackColor = _bgDark;
            this.ForeColor = Color.White;
            this.Font = new Font("Segoe UI", 9.5f, FontStyle.Regular);

            // ==========================================
            // 1. ÜST BAŞLIK ALANI (SADE LOGO + ARCLIGHT)
            // ==========================================
            Panel headerPanel = new Panel
            {
                Location = new Point(18, 12),
                Size = new Size(458, 46),
                BackColor = Color.Transparent
            };

            PictureBox picLogo = new PictureBox
            {
                Image = CreateLogoBitmap(38),
                Size = new Size(38, 38),
                Location = new Point(0, 4),
                SizeMode = PictureBoxSizeMode.Zoom
            };
            headerPanel.Controls.Add(picLogo);

            Label lblTitle = new Label
            {
                Text = "ArcLight",
                Font = new Font("Segoe UI", 18f, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(48, 4),
                AutoSize = true
            };
            headerPanel.Controls.Add(lblTitle);

            this.Controls.Add(headerPanel);

            // ==========================================
            // 2. MODERN SEKME BUTONLARI (TAB STRIP)
            // ==========================================
            Panel tabStrip = new Panel
            {
                Location = new Point(18, 64),
                Size = new Size(458, 40),
                BackColor = Color.Transparent
            };

            int tabW = 150;
            _tabBtnLight = CreateTabButton(Loc.T("TabLight"), 0, 0, tabW, 0);
            _tabBtnLocation = CreateTabButton(Loc.T("TabLocation"), tabW + 4, 0, tabW, 1);
            _tabBtnSettings = CreateTabButton(Loc.T("TabSettings"), (tabW + 4) * 2, 0, tabW, 2);

            tabStrip.Controls.Add(_tabBtnLight);
            tabStrip.Controls.Add(_tabBtnLocation);
            tabStrip.Controls.Add(_tabBtnSettings);
            this.Controls.Add(tabStrip);

            // ==========================================
            // 3. SEKME İÇERİK KONTEYNERLERİ
            // ==========================================
            int contentY = 112;
            int contentW = 458;
            int contentH = 475;

            // --- SEKME 1: IŞIK & PARLAKLIK ---
            _panelLightTab = new Panel
            {
                Location = new Point(18, contentY),
                Size = new Size(contentW, contentH),
                BackColor = Color.Transparent
            };
            BuildLightTabUI(_panelLightTab);
            this.Controls.Add(_panelLightTab);

            // --- SEKME 2: LOKASYON & ZAMANLAMA ---
            _panelLocationTab = new Panel
            {
                Location = new Point(18, contentY),
                Size = new Size(contentW, contentH),
                BackColor = Color.Transparent,
                Visible = false
            };
            BuildLocationTabUI(_panelLocationTab);
            this.Controls.Add(_panelLocationTab);

            // --- SEKME 3: AYARLAR & DİL ---
            _panelSettingsTab = new Panel
            {
                Location = new Point(18, contentY),
                Size = new Size(contentW, contentH),
                BackColor = Color.Transparent,
                Visible = false
            };
            BuildSettingsTabUI(_panelSettingsTab);
            this.Controls.Add(_panelSettingsTab);

            SwitchTab(0);
            UpdateLabels();
            UpdateToggleButtonState();
        }

        private Button CreateTabButton(string text, int x, int y, int width, int tabIndex)
        {
            Button btn = new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(width, 36),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.2f, FontStyle.Bold),
                ForeColor = Color.FromArgb(200, 200, 210),
                BackColor = _tabInactive,
                Cursor = Cursors.Hand
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.Click += (s, e) => SwitchTab(tabIndex);
            return btn;
        }

        private void SwitchTab(int index)
        {
            _tabBtnLight.BackColor = (index == 0) ? _tabActive : _tabInactive;
            _tabBtnLight.ForeColor = (index == 0) ? _accentOrange : Color.FromArgb(180, 180, 190);

            _tabBtnLocation.BackColor = (index == 1) ? _tabActive : _tabInactive;
            _tabBtnLocation.ForeColor = (index == 1) ? _accentOrange : Color.FromArgb(180, 180, 190);

            _tabBtnSettings.BackColor = (index == 2) ? _tabActive : _tabInactive;
            _tabBtnSettings.ForeColor = (index == 2) ? _accentOrange : Color.FromArgb(180, 180, 190);

            _panelLightTab.Visible = (index == 0);
            _panelLocationTab.Visible = (index == 1);
            _panelSettingsTab.Visible = (index == 2);
        }

        // ==========================================
        // SEKME 1: IŞIK & PARLAKLIK İÇERİĞİ
        // ==========================================
        private void BuildLightTabUI(Panel panel)
        {
            int curY = 0;

            // KART 1: BÜYÜK AÇ/KAPAT BUTONU
            Panel cardToggle = CreateCardPanel(0, curY, 458, 120);

            _btnToggle = new Button
            {
                Location = new Point(16, 14),
                Size = new Size(426, 58),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 13f, FontStyle.Bold),
                Cursor = Cursors.Hand,
                ForeColor = Color.White
            };
            _btnToggle.FlatAppearance.BorderSize = 0;
            _btnToggle.Click += (s, e) =>
            {
                _settings.IsEnabled = !_settings.IsEnabled;
                UpdateToggleButtonState();
                ApplyCurrentSettingsImmediate();
                _settings.Save();
            };
            cardToggle.Controls.Add(_btnToggle);

            _lblStatusText = new Label
            {
                Location = new Point(16, 80),
                Size = new Size(426, 26),
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 9.2f, FontStyle.Regular),
                ForeColor = Color.FromArgb(180, 180, 190)
            };
            cardToggle.Controls.Add(_lblStatusText);

            panel.Controls.Add(cardToggle);
            curY += 134;

            // KART 2: SÜRGÜLER VE HAZIR PROFİLLER
            Panel cardSliders = CreateCardPanel(0, curY, 458, 236);

            // Sıcaklık
            _lblKTitle = new Label
            {
                Text = Loc.T("ColorTemp"),
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(14, 14),
                AutoSize = true
            };
            cardSliders.Controls.Add(_lblKTitle);

            _lblKelvinVal = new Label
            {
                Text = _settings.Kelvin + " K",
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = _accentOrange,
                Location = new Point(220, 14),
                Size = new Size(224, 20),
                TextAlign = ContentAlignment.MiddleRight
            };
            cardSliders.Controls.Add(_lblKelvinVal);

            _tbKelvin = new TrackBar
            {
                Location = new Point(12, 40),
                Size = new Size(434, 45),
                Minimum = 1800,
                Maximum = 6500,
                TickFrequency = 500,
                SmallChange = 100,
                LargeChange = 500,
                Value = Math.Max(1800, Math.Min(6500, _settings.Kelvin)),
                Cursor = Cursors.Hand
            };
            _tbKelvin.Scroll += (s, e) => HandleKelvinChange();
            _tbKelvin.ValueChanged += (s, e) => HandleKelvinChange();
            cardSliders.Controls.Add(_tbKelvin);

            // Parlaklık
            _lblBTitle = new Label
            {
                Text = Loc.T("Brightness"),
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(14, 104),
                AutoSize = true
            };
            cardSliders.Controls.Add(_lblBTitle);

            _lblBrightnessVal = new Label
            {
                Text = "%" + _settings.Brightness,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = _accentGold,
                Location = new Point(290, 104),
                Size = new Size(154, 20),
                TextAlign = ContentAlignment.MiddleRight
            };
            cardSliders.Controls.Add(_lblBrightnessVal);

            _tbBrightness = new TrackBar
            {
                Location = new Point(12, 130),
                Size = new Size(434, 45),
                Minimum = 25,
                Maximum = 100,
                TickFrequency = 5,
                SmallChange = 5,
                LargeChange = 10,
                Value = Math.Max(25, Math.Min(100, _settings.Brightness)),
                Cursor = Cursors.Hand
            };
            _tbBrightness.Scroll += (s, e) => HandleBrightnessChange();
            _tbBrightness.ValueChanged += (s, e) => HandleBrightnessChange();
            cardSliders.Controls.Add(_tbBrightness);

            // Hızlı Profil Butonları
            int btnX = 14;
            int btnW = 100;
            _btnPresetCandle = CreatePresetButton(Loc.T("PresetCandle"), 2200, 75, btnX, 184, btnW);
            btnX += 108;
            _btnPresetNight = CreatePresetButton(Loc.T("PresetNight"), 3400, 85, btnX, 184, btnW);
            btnX += 108;
            _btnPresetSunset = CreatePresetButton(Loc.T("PresetSunset"), 4500, 95, btnX, 184, btnW);
            btnX += 108;
            _btnPresetNormal = CreatePresetButton(Loc.T("PresetNormal"), 6500, 100, btnX, 184, btnW);

            cardSliders.Controls.Add(_btnPresetCandle);
            cardSliders.Controls.Add(_btnPresetNight);
            cardSliders.Controls.Add(_btnPresetSunset);
            cardSliders.Controls.Add(_btnPresetNormal);

            panel.Controls.Add(cardSliders);
        }

        private void HandleKelvinChange()
        {
            if (_isUpdatingUI) return;
            _settings.Kelvin = _tbKelvin.Value;
            UpdateLabels();

            // Kullanıcı kaydırıcıyı çektiğinde gece modu kapalıysa anında aç
            if (!_settings.IsEnabled)
            {
                _settings.IsEnabled = true;
                UpdateToggleButtonState();
            }

            ApplyCurrentSettingsImmediate();
            TriggerDebouncedSave();
        }

        private void HandleBrightnessChange()
        {
            if (_isUpdatingUI) return;
            _settings.Brightness = _tbBrightness.Value;
            UpdateLabels();

            // Kullanıcı kaydırıcıyı çektiğinde gece modu kapalıysa anında aç
            if (!_settings.IsEnabled)
            {
                _settings.IsEnabled = true;
                UpdateToggleButtonState();
            }

            ApplyCurrentSettingsImmediate();
            TriggerDebouncedSave();
        }

        // ==========================================
        // SEKME 2: LOKASYON & ZAMANLAMA İÇERİĞİ
        // ==========================================
        private void BuildLocationTabUI(Panel panel)
        {
            Panel card = CreateCardPanel(0, 0, 458, 380);

            _lblSchedTitle = new Label
            {
                Text = Loc.T("SchedTitle"),
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(16, 14),
                AutoSize = true
            };
            card.Controls.Add(_lblSchedTitle);

            // Radyo Butonları
            _rbSunMode = new RadioButton
            {
                Text = Loc.T("ModeSun"),
                Location = new Point(18, 48),
                AutoSize = true,
                Checked = (_settings.ScheduleMode == 0),
                ForeColor = Color.White,
                Cursor = Cursors.Hand
            };
            _rbSunMode.CheckedChanged += (s, e) => { if (_rbSunMode.Checked) ChangeScheduleMode(0); };
            card.Controls.Add(_rbSunMode);

            _rbCustomMode = new RadioButton
            {
                Text = Loc.T("ModeCustom"),
                Location = new Point(18, 76),
                AutoSize = true,
                Checked = (_settings.ScheduleMode == 1),
                ForeColor = Color.White,
                Cursor = Cursors.Hand
            };
            _rbCustomMode.CheckedChanged += (s, e) => { if (_rbCustomMode.Checked) ChangeScheduleMode(1); };
            card.Controls.Add(_rbCustomMode);

            _rbManualMode = new RadioButton
            {
                Text = Loc.T("ModeManual"),
                Location = new Point(18, 104),
                AutoSize = true,
                Checked = (_settings.ScheduleMode == 2),
                ForeColor = Color.White,
                Cursor = Cursors.Hand
            };
            _rbManualMode.CheckedChanged += (s, e) => { if (_rbManualMode.Checked) ChangeScheduleMode(2); };
            card.Controls.Add(_rbManualMode);

            // 1. Güneş / Şehir Paneli
            _panelSunSettings = new Panel
            {
                Location = new Point(16, 140),
                Size = new Size(426, 215),
                BackColor = Color.FromArgb(22, 22, 28)
            };

            _lblCity = new Label
            {
                Text = Loc.T("CitySelect"),
                Location = new Point(14, 16),
                AutoSize = true,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Color.White
            };
            _panelSunSettings.Controls.Add(_lblCity);

            _cbCity = new ComboBox
            {
                Location = new Point(14, 44),
                Size = new Size(398, 28),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Color.FromArgb(42, 42, 52),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10f),
                Cursor = Cursors.Hand
            };
            foreach (var c in SolarCalculator.Cities)
            {
                _cbCity.Items.Add(c);
            }
            SelectCityInCombo(_settings.CityName);
            _cbCity.SelectedIndexChanged += (s, e) =>
            {
                var sel = _cbCity.SelectedItem as SolarCalculator.CityInfo;
                if (sel != null)
                {
                    _settings.CityName = sel.Name;
                    UpdateSolarCalculations();
                    _settings.Save();
                    CheckScheduleAndApply(true);
                }
            };
            _panelSunSettings.Controls.Add(_cbCity);

            _lblSolarInfo = new Label
            {
                Location = new Point(14, 88),
                Size = new Size(398, 110),
                Font = new Font("Segoe UI", 10f, FontStyle.Regular),
                ForeColor = _accentGold
            };
            _panelSunSettings.Controls.Add(_lblSolarInfo);
            card.Controls.Add(_panelSunSettings);

            // 2. Özel Saat Aralığı Paneli
            _panelCustomSettings = new Panel
            {
                Location = new Point(16, 140),
                Size = new Size(426, 215),
                BackColor = Color.FromArgb(22, 22, 28),
                Visible = false
            };

            _lblStart = new Label
            {
                Text = Loc.T("StartTime"),
                Location = new Point(18, 30),
                AutoSize = true,
                Font = new Font("Segoe UI", 10.5f, FontStyle.Bold),
                ForeColor = Color.White
            };
            _panelCustomSettings.Controls.Add(_lblStart);

            _dtpStart = new DateTimePicker
            {
                Format = DateTimePickerFormat.Custom,
                CustomFormat = "HH:mm",
                ShowUpDown = true,
                Location = new Point(230, 26),
                Size = new Size(110, 28),
                Font = new Font("Segoe UI", 11f),
                Value = DateTime.Today.Add(_settings.CustomStartTime),
                Cursor = Cursors.Hand
            };
            _dtpStart.ValueChanged += (s, e) =>
            {
                _settings.CustomStartTime = _dtpStart.Value.TimeOfDay;
                _settings.Save();
                CheckScheduleAndApply(true);
            };
            _panelCustomSettings.Controls.Add(_dtpStart);

            _lblEnd = new Label
            {
                Text = Loc.T("EndTime"),
                Location = new Point(18, 90),
                AutoSize = true,
                Font = new Font("Segoe UI", 10.5f, FontStyle.Bold),
                ForeColor = Color.White
            };
            _panelCustomSettings.Controls.Add(_lblEnd);

            _dtpEnd = new DateTimePicker
            {
                Format = DateTimePickerFormat.Custom,
                CustomFormat = "HH:mm",
                ShowUpDown = true,
                Location = new Point(230, 86),
                Size = new Size(110, 28),
                Font = new Font("Segoe UI", 11f),
                Value = DateTime.Today.Add(_settings.CustomEndTime),
                Cursor = Cursors.Hand
            };
            _dtpEnd.ValueChanged += (s, e) =>
            {
                _settings.CustomEndTime = _dtpEnd.Value.TimeOfDay;
                _settings.Save();
                CheckScheduleAndApply(true);
            };
            _panelCustomSettings.Controls.Add(_dtpEnd);
            card.Controls.Add(_panelCustomSettings);

            panel.Controls.Add(card);

            UpdatePanelVisibility();
            UpdateSolarCalculations();
        }

        // ==========================================
        // SEKME 3: AYARLAR & DİL İÇERİĞİ
        // ==========================================
        private void BuildSettingsTabUI(Panel panel)
        {
            Panel card = CreateCardPanel(0, 0, 458, 380);

            // Dil Seçimi
            _lblLangTitle = new Label
            {
                Text = Loc.T("LangTitle"),
                Font = new Font("Segoe UI", 10.5f, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(16, 18),
                AutoSize = true
            };
            card.Controls.Add(_lblLangTitle);

            _cbLanguage = new ComboBox
            {
                Location = new Point(16, 48),
                Size = new Size(424, 30),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Color.FromArgb(42, 42, 52),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10.5f),
                Cursor = Cursors.Hand
            };

            // 7 Dil Seçeneği
            _cbLanguage.Items.Add(new LanguageItem("tr", "🇹🇷 Türkçe"));
            _cbLanguage.Items.Add(new LanguageItem("en", "🇬🇧 English"));
            _cbLanguage.Items.Add(new LanguageItem("es", "🇪🇸 Español"));
            _cbLanguage.Items.Add(new LanguageItem("fr", "🇫🇷 Français"));
            _cbLanguage.Items.Add(new LanguageItem("zh", "🇨🇳 简体中文 (Chinese)"));
            _cbLanguage.Items.Add(new LanguageItem("ja", "🇯🇵 日本語 (Japanese)"));
            _cbLanguage.Items.Add(new LanguageItem("ko", "🇰🇷 한국어 (Korean)"));

            SelectLanguageInCombo(_settings.Language);
            _cbLanguage.SelectedIndexChanged += (s, e) =>
            {
                var item = _cbLanguage.SelectedItem as LanguageItem;
                if (item != null)
                {
                    _settings.Language = item.Code;
                    Loc.CurrentLang = item.Code;
                    _settings.Save();
                    ApplyLanguageChanges();
                }
            };
            card.Controls.Add(_cbLanguage);

            // Başlangıç Ayarları
            _chkAutoStart = new CheckBox
            {
                Text = Loc.T("AutoStart"),
                Location = new Point(18, 108),
                AutoSize = true,
                Checked = _settings.AutoStart,
                ForeColor = Color.White,
                Cursor = Cursors.Hand
            };
            _chkAutoStart.CheckedChanged += (s, e) =>
            {
                _settings.AutoStart = _chkAutoStart.Checked;
                SetAutoStartRegistry(_settings.AutoStart);
                _settings.Save();
            };
            card.Controls.Add(_chkAutoStart);

            _chkMinimizeTray = new CheckBox
            {
                Text = Loc.T("MinimizeTray"),
                Location = new Point(18, 144),
                AutoSize = true,
                Checked = _settings.MinimizeToTray,
                ForeColor = Color.White,
                Cursor = Cursors.Hand
            };
            _chkMinimizeTray.CheckedChanged += (s, e) =>
            {
                _settings.MinimizeToTray = _chkMinimizeTray.Checked;
                _settings.Save();
            };
            card.Controls.Add(_chkMinimizeTray);

            // TEK TIKLA ÇIKIŞ BUTONU
            _btnExitApp = new Button
            {
                Text = Loc.T("ExitApp"),
                Location = new Point(16, 210),
                Size = new Size(424, 48),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(153, 27, 27),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10.5f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            _btnExitApp.FlatAppearance.BorderSize = 0;
            _btnExitApp.Click += (s, e) => ExitApplication();
            card.Controls.Add(_btnExitApp);

            panel.Controls.Add(card);
        }

        private class LanguageItem
        {
            public string Code { get; set; }
            public string Display { get; set; }
            public LanguageItem(string code, string display) { Code = code; Display = display; }
            public override string ToString() { return Display; }
        }

        private void SelectLanguageInCombo(string code)
        {
            for (int i = 0; i < _cbLanguage.Items.Count; i++)
            {
                var item = _cbLanguage.Items[i] as LanguageItem;
                if (item != null && item.Code.Equals(code, StringComparison.OrdinalIgnoreCase))
                {
                    _cbLanguage.SelectedIndex = i;
                    return;
                }
            }
            if (_cbLanguage.Items.Count > 0) _cbLanguage.SelectedIndex = 0;
        }

        private void ApplyLanguageChanges()
        {
            // Sekme Başlıkları
            _tabBtnLight.Text = Loc.T("TabLight");
            _tabBtnLocation.Text = Loc.T("TabLocation");
            _tabBtnSettings.Text = Loc.T("TabSettings");

            // Sekme 1
            _lblKTitle.Text = Loc.T("ColorTemp");
            _lblBTitle.Text = Loc.T("Brightness");
            _btnPresetCandle.Text = Loc.T("PresetCandle");
            _btnPresetNight.Text = Loc.T("PresetNight");
            _btnPresetSunset.Text = Loc.T("PresetSunset");
            _btnPresetNormal.Text = Loc.T("PresetNormal");

            // Sekme 2
            _lblSchedTitle.Text = Loc.T("SchedTitle");
            _rbSunMode.Text = Loc.T("ModeSun");
            _rbCustomMode.Text = Loc.T("ModeCustom");
            _rbManualMode.Text = Loc.T("ModeManual");
            _lblCity.Text = Loc.T("CitySelect");
            _lblStart.Text = Loc.T("StartTime");
            _lblEnd.Text = Loc.T("EndTime");

            // Sekme 3
            _lblLangTitle.Text = Loc.T("LangTitle");
            _chkAutoStart.Text = Loc.T("AutoStart");
            _chkMinimizeTray.Text = Loc.T("MinimizeTray");
            _btnExitApp.Text = Loc.T("ExitApp");

            UpdateLabels();
            UpdateToggleButtonState();
            UpdateSolarCalculations();
        }

        private Panel CreateCardPanel(int x, int y, int width, int height)
        {
            Panel p = new Panel
            {
                Location = new Point(x, y),
                Size = new Size(width, height),
                BackColor = _cardDark
            };
            p.Paint += (s, e) =>
            {
                using (Pen pen = new Pen(Color.FromArgb(50, 50, 60), 1))
                {
                    e.Graphics.DrawRectangle(pen, 0, 0, width - 1, height - 1);
                }
            };
            return p;
        }

        private Button CreatePresetButton(string text, int kelvin, int brightness, int x, int y, int width)
        {
            Button btn = new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(width, 32),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(42, 42, 52),
                ForeColor = Color.FromArgb(220, 220, 230),
                Font = new Font("Segoe UI", 8.5f, FontStyle.Regular),
                Cursor = Cursors.Hand
            };
            btn.FlatAppearance.BorderColor = Color.FromArgb(65, 65, 75);
            btn.Click += (s, e) =>
            {
                _isUpdatingUI = true;
                _settings.Kelvin = kelvin;
                _settings.Brightness = brightness;
                _tbKelvin.Value = Math.Max(1800, Math.Min(6500, kelvin));
                _tbBrightness.Value = Math.Max(25, Math.Min(100, brightness));
                _isUpdatingUI = false;

                if (!_settings.IsEnabled)
                {
                    _settings.IsEnabled = true;
                    UpdateToggleButtonState();
                }
                UpdateLabels();
                ApplyCurrentSettingsImmediate();
                _settings.Save();
            };
            return btn;
        }

        private void ChangeScheduleMode(int mode)
        {
            _settings.ScheduleMode = mode;
            UpdatePanelVisibility();
            _settings.Save();
            CheckScheduleAndApply(true);
        }

        private void UpdatePanelVisibility()
        {
            if (_settings.ScheduleMode == 0)
            {
                _panelSunSettings.Visible = true;
                _panelCustomSettings.Visible = false;
            }
            else if (_settings.ScheduleMode == 1)
            {
                _panelSunSettings.Visible = false;
                _panelCustomSettings.Visible = true;
            }
            else
            {
                _panelSunSettings.Visible = false;
                _panelCustomSettings.Visible = false;
            }
        }

        private void SelectCityInCombo(string cityName)
        {
            for (int i = 0; i < _cbCity.Items.Count; i++)
            {
                var city = _cbCity.Items[i] as SolarCalculator.CityInfo;
                if (city != null && city.Name.Equals(cityName, StringComparison.OrdinalIgnoreCase))
                {
                    _cbCity.SelectedIndex = i;
                    return;
                }
            }
            if (_cbCity.Items.Count > 0) _cbCity.SelectedIndex = 0;
        }

        private void UpdateSolarCalculations()
        {
            if (_cbCity == null || _cbCity.SelectedItem == null) return;
            var city = _cbCity.SelectedItem as SolarCalculator.CityInfo;
            if (city == null) return;

            TimeSpan sunrise, sunset;
            SolarCalculator.CalculateSunriseSunset(city.Latitude, city.Longitude, DateTime.Now, out sunrise, out sunset);

            string riseStr = string.Format("{0:D2}:{1:D2}", sunrise.Hours, sunrise.Minutes);
            string setStr = string.Format("{0:D2}:{1:D2}", sunset.Hours, sunset.Minutes);

            _lblSolarInfo.Text = string.Format(Loc.T("SunriseSunset"), riseStr, setStr);
        }

        private void SetupTimer()
        {
            _scheduleTimer = new Timer();
            _scheduleTimer.Interval = 20000;
            _scheduleTimer.Tick += (s, e) => CheckScheduleAndApply(false);
            _scheduleTimer.Start();
        }

        private void CheckScheduleAndApply(bool force)
        {
            if (_settings.ScheduleMode == 2) // Manuel
            {
                if (force) ApplyCurrentSettingsImmediate();
                return;
            }

            TimeSpan now = DateTime.Now.TimeOfDay;
            TimeSpan start, end;

            if (_settings.ScheduleMode == 0) // Güneş / Lokasyon
            {
                var city = _cbCity != null && _cbCity.SelectedItem != null 
                    ? _cbCity.SelectedItem as SolarCalculator.CityInfo 
                    : SolarCalculator.Cities[0];
                if (city == null) city = SolarCalculator.Cities[0];

                TimeSpan sunrise, sunset;
                SolarCalculator.CalculateSunriseSunset(city.Latitude, city.Longitude, DateTime.Now, out sunrise, out sunset);
                start = sunset;
                end = sunrise;
            }
            else // Özel Saat
            {
                start = _settings.CustomStartTime;
                end = _settings.CustomEndTime;
            }

            bool shouldBeNight;
            if (start <= end)
            {
                shouldBeNight = (now >= start && now < end);
            }
            else
            {
                shouldBeNight = (now >= start || now < end);
            }

            if (force)
            {
                _lastScheduleNightState = shouldBeNight;
                _settings.IsEnabled = shouldBeNight;
                UpdateToggleButtonState();
                ApplyCurrentSettingsImmediate();
            }
            else
            {
                // Sadece gün doğumunda veya gün batımında gerçek bir geçiş olduğunda tetikle!
                // Böylece kullanıcının el ile kaydırdığı ayarı 20 saniye sonra zorla ezmez.
                if (_lastScheduleNightState.HasValue && _lastScheduleNightState.Value != shouldBeNight)
                {
                    _lastScheduleNightState = shouldBeNight;
                    _settings.IsEnabled = shouldBeNight;
                    UpdateToggleButtonState();
                    ApplyCurrentSettingsImmediate();
                }
                else if (!_lastScheduleNightState.HasValue)
                {
                    _lastScheduleNightState = shouldBeNight;
                }
            }
        }

        private void UpdateToggleButtonState()
        {
            if (_settings.IsEnabled)
            {
                _btnToggle.Text = Loc.T("NightModeOn");
                _btnToggle.BackColor = _accentOrange;
                _lblStatusText.Text = Loc.T("StatusNight") + " " + Loc.T("ClickToToggle");
                _lblStatusText.ForeColor = Color.FromArgb(253, 186, 116);
            }
            else
            {
                _btnToggle.Text = Loc.T("NightModeOff");
                _btnToggle.BackColor = _offGray;
                _lblStatusText.Text = Loc.T("StatusDay") + " " + Loc.T("ClickToToggle");
                _lblStatusText.ForeColor = Color.FromArgb(161, 161, 170);
            }
        }

        private void UpdateLabels()
        {
            string desc = "";
            if (_settings.Kelvin <= 2400) desc = " (" + Loc.T("DescCandle") + ")";
            else if (_settings.Kelvin <= 3400) desc = " (" + Loc.T("DescNight") + ")";
            else if (_settings.Kelvin <= 4500) desc = " (" + Loc.T("DescSunset") + ")";
            else if (_settings.Kelvin < 6000) desc = " (K)";
            else desc = " (" + Loc.T("DescNormal") + ")";

            _lblKelvinVal.Text = _settings.Kelvin + " K " + desc;
            _lblBrightnessVal.Text = "%" + _settings.Brightness;
        }

        private void ApplyCurrentSettingsImmediate()
        {
            if (_settings.IsEnabled)
            {
                GammaController.SetColorTemperatureAndBrightness(_settings.Kelvin, _settings.Brightness);
            }
            else
            {
                GammaController.RestoreDefault();
            }
        }

        private void SetupTrayIcon()
        {
            _trayMenu = new ContextMenuStrip();

            var itemToggle = new ToolStripMenuItem(Loc.T("TrayToggle"));
            itemToggle.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
            itemToggle.Click += (s, e) =>
            {
                _settings.IsEnabled = !_settings.IsEnabled;
                UpdateToggleButtonState();
                ApplyCurrentSettingsImmediate();
                _settings.Save();
            };

            var itemOpen = new ToolStripMenuItem(Loc.T("TrayOpen"));
            itemOpen.Click += (s, e) => ShowWindow();

            var itemExit = new ToolStripMenuItem(Loc.T("TrayExit"));
            itemExit.Click += (s, e) => ExitApplication();

            _trayMenu.Items.Add(itemToggle);
            _trayMenu.Items.Add(itemOpen);
            _trayMenu.Items.Add(new ToolStripSeparator());
            _trayMenu.Items.Add(itemExit);

            _trayIcon = new NotifyIcon
            {
                Text = "ArcLight",
                Icon = this.Icon,
                ContextMenuStrip = _trayMenu,
                Visible = true
            };

            _trayIcon.MouseClick += (s, e) =>
            {
                if (e.Button == MouseButtons.Left)
                {
                    _settings.IsEnabled = !_settings.IsEnabled;
                    UpdateToggleButtonState();
                    ApplyCurrentSettingsImmediate();
                    _settings.Save();
                }
            };

            _trayIcon.DoubleClick += (s, e) => ShowWindow();
        }

        private void ShowWindow()
        {
            this.Show();
            this.WindowState = FormWindowState.Normal;
            this.BringToFront();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing && _settings.MinimizeToTray)
            {
                e.Cancel = true;
                this.Hide();
                _trayIcon.ShowBalloonTip(1500, "ArcLight", Loc.T("ClickToToggle"), ToolTipIcon.Info);
            }
            else
            {
                ExitApplication();
            }
            base.OnFormClosing(e);
        }

        private void ExitApplication()
        {
            if (_scheduleTimer != null)
            {
                _scheduleTimer.Stop();
                _scheduleTimer.Dispose();
            }
            if (_saveDebounceTimer != null)
            {
                _saveDebounceTimer.Stop();
                _saveDebounceTimer.Dispose();
            }
            GammaController.RestoreDefault();
            if (_trayIcon != null)
            {
                _trayIcon.Visible = false;
                _trayIcon.Dispose();
            }
            _settings.Save();
            Application.ExitThread();
            Environment.Exit(0);
        }

        public static Bitmap CreateLogoBitmap(int size)
        {
            Bitmap bmp = new Bitmap(size, size);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.HighQuality;
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.Clear(Color.Transparent);

                float s = (float)size;

                // 1. Dış İnce Glow / Yumuşak Halka
                using (GraphicsPath pGlow = new GraphicsPath())
                {
                    pGlow.AddEllipse(s * 0.02f, s * 0.02f, s * 0.96f, s * 0.96f);
                    using (PathGradientBrush pgb = new PathGradientBrush(pGlow))
                    {
                        pgb.CenterColor = Color.FromArgb(249, 115, 22);
                        pgb.SurroundColors = new Color[] { Color.FromArgb(0, 249, 115, 22) };
                        g.FillPath(pgb, pGlow);
                    }
                }

                // 2. Koyu Modern Zemin
                using (Brush bgBrush = new SolidBrush(Color.FromArgb(22, 22, 28)))
                {
                    g.FillEllipse(bgBrush, s * 0.04f, s * 0.04f, s * 0.92f, s * 0.92f);
                }

                // 3. Şık Çerçeve (Vibrant Orange)
                float penW = Math.Max(1.2f, s * 0.045f);
                using (Pen ringPen = new Pen(Color.FromArgb(249, 115, 22), penW))
                {
                    g.DrawEllipse(ringPen, s * 0.05f, s * 0.05f, s * 0.90f, s * 0.90f);
                }

                // 4. Geometrik Keskin Büyük 'A' Harfi
                using (GraphicsPath aPath = new GraphicsPath())
                {
                    PointF topOuter = new PointF(s * 0.50f, s * 0.15f);
                    PointF btmLeftOuter = new PointF(s * 0.19f, s * 0.83f);
                    PointF btmLeftInner = new PointF(s * 0.33f, s * 0.83f);
                    PointF btmRightInner = new PointF(s * 0.67f, s * 0.83f);
                    PointF btmRightOuter = new PointF(s * 0.81f, s * 0.83f);

                    PointF[] aOutline = new PointF[]
                    {
                        topOuter,
                        btmRightOuter,
                        btmRightInner,
                        new PointF(s * 0.63f, s * 0.66f),
                        new PointF(s * 0.37f, s * 0.66f),
                        btmLeftInner,
                        btmLeftOuter
                    };
                    aPath.AddPolygon(aOutline);

                    PointF topHole = new PointF(s * 0.50f, s * 0.32f);
                    PointF leftHole = new PointF(s * 0.40f, s * 0.54f);
                    PointF rightHole = new PointF(s * 0.60f, s * 0.54f);
                    GraphicsPath holePath = new GraphicsPath();
                    holePath.AddPolygon(new PointF[] { topHole, rightHole, leftHole });

                    using (Region reg = new Region(aPath))
                    {
                        reg.Exclude(holePath);
                        using (Brush aBrush = new SolidBrush(Color.White))
                        {
                            g.FillRegion(aBrush, reg);
                        }
                    }
                }

                // 5. 'A' Harfinin Ortasında Parlayan Altın Yıldız (5 Köşeli)
                PointF starCenter = new PointF(s * 0.50f, s * 0.44f);
                float outerR = s * 0.125f;
                float innerR = outerR * 0.48f;
                PointF[] starPts = new PointF[10];
                double step = Math.PI / 5.0;
                double startAngle = -Math.PI / 2.0;
                for (int i = 0; i < 10; i++)
                {
                    float r = (i % 2 == 0) ? outerR : innerR;
                    double a = startAngle + i * step;
                    starPts[i] = new PointF(starCenter.X + (float)(r * Math.Cos(a)), starCenter.Y + (float)(r * Math.Sin(a)));
                }

                using (Brush starBrush = new SolidBrush(Color.FromArgb(251, 191, 36)))
                {
                    g.FillPolygon(starBrush, starPts);
                }
                using (Pen starBorder = new Pen(Color.FromArgb(217, 119, 6), Math.Max(0.6f, s * 0.015f)))
                {
                    g.DrawPolygon(starBorder, starPts);
                }
            }
            return bmp;
        }

        private static Icon CreateAppIcon()
        {
            try
            {
                string icoPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "app.ico");
                if (File.Exists(icoPath)) return new Icon(icoPath);
                Icon assoc = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
                if (assoc != null) return assoc;
            }
            catch { }
            Bitmap bmp = CreateLogoBitmap(48);
            return Icon.FromHandle(bmp.GetHicon());
        }

        private void SetAutoStartRegistry(bool enable)
        {
            try
            {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true))
                {
                    if (key != null)
                    {
                        if (enable)
                        {
                            key.SetValue("ArcLight", "\"" + Application.ExecutablePath + "\"");
                        }
                        else
                        {
                            key.DeleteValue("ArcLight", false);
                        }
                    }
                }
            }
            catch { }
        }
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

        [DllImport("shell32.dll", SetLastError = true)]
        public static extern void SetCurrentProcessExplicitAppUserModelID([MarshalAs(UnmanagedType.LPWStr)] string AppID);

        private const uint WM_SETICON = 0x0080;
        private static readonly IntPtr ICON_SMALL = (IntPtr)0;
        private static readonly IntPtr ICON_BIG = (IntPtr)1;

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            try
            {
                if (this.Icon != null)
                {
                    SendMessage(this.Handle, WM_SETICON, ICON_SMALL, this.Icon.Handle);
                    SendMessage(this.Handle, WM_SETICON, ICON_BIG, this.Icon.Handle);
                }
            }
            catch { }
        }
    }

    // ==========================================
    // GİRİŞ NOKTASI
    // ==========================================
    static class Program
    {
        [STAThread]
        static void Main()
        {
            try
            {
                MainForm.SetCurrentProcessExplicitAppUserModelID("ArcLight.NightLight.DesktopApp");
            }
            catch { }

            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new MainForm());
            }
            catch (Exception ex)
            {
                File.WriteAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "hata.log"), ex.ToString());
            }
        }
    }
}
