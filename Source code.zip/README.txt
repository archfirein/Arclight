ArcLight - Akıllı Gece Modu & Mavi Işık Filtresi (v1.0)
======================================================

ArcLight, gözlerinizi mavi ışığın zararlı etkilerinden koruyan ve ekranınızı günün saatine göre otomatik olarak ayarlayan modern bir Windows uygulamasıdır.

Öne Çıkan Özellikler:
---------------------
- Donanımsal Gamma Desteği (Oyunlarda ve videolarda asla FPS/performans kaybı yapmaz)
- Güneş Takibi (Şehrinizin enlem/boylamına göre gün doğumu ve batımında otomatik geçiş)
- Özel Saat Aralığı ve Manuel Mod
- 7 Farklı Dil Desteği (Türkçe, İngilizce, İspanyolca, Fransızca, Çince, Japonca, Korece)
- Tek Tıkla Aç/Kapat (Arayüzden veya sistem tepsisinden tek tıkla kontrol)
- Ekran Parlaklığı ve Renk Sıcaklığı Sürgüleri (1800K - 6500K)
- Taşınabilir (Portable): Kurulum gerektirmeden tek başına çalışabilir.

Kurulum:
--------
1. "ArcLight-Installer.win-x64.exe" dosyasını çalıştırarak kolayca kurabilir veya,
2. "ArcLight.exe" dosyasını doğrudan çalıştırarak taşınabilir (portable) olarak kullanabilirsiniz.
